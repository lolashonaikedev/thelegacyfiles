import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import saito.objloader.*; 
import processing.opengl.*; 
import peasy.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class WriteLegendText extends PApplet {

//import sftp.*;
//Sftp sftp;


 
 
OBJModel model; 
float rotX; 
float rotY; 

PShape alien;  
//PImage img;
ArrayList stars;
PFont Cat, catStage, ttools, tstage, buttons;


float cl, cp, ht, OUR,cl1,cl2,cl3,cl4,cp1,cp2,cp3,cp4,ht1,ht2,ht3,ht4,OUR1,OUR2,OUR3,OUR4,ad,ad1,ad2,ad3,ad4,ss,ss1,ss2,ss3,ss4,md,md1,md2,md3,md4,ct,ct1,ct2,ct3,ct4,sd,sd1,sd2,sd3,sd4,pt,pt1,pt2,pt3,pt4,nb,nb1,nb2,nb3,nb4,pl,pl1,pl2,pl3,pl4,pd,pd1,pd2,pd3,pd4;
float mc,mc1,mc2,mc3,mc4,mt,mt1,mt2,sc,sc1,sc2,sc3,sc4;
float thetaMercury, thetaVenus, thetaVenusMoon, thetaEarth, thetaEarthMoon, thetaMars, thetaMarsMoon1, thetaMarsMoon2, thetaJupiter, thetaSaturn, thetaUranus, thetaNeptune, thetaPluto; 

PeasyCam cam;
PeasyDragHandler PanDragHandler;
PeasyDragHandler ZoomDragHandler;
String selection;

public void setup () {
  
 selectInput(" a file to process:", "fileSelected");


//int(totalCat);
//int(phase1cat);
//int(totalTool);

 size (1300,700,OPENGL);
// if (mouseClicked)
//scaleFactor=100;

 cam = new PeasyCam(this,width/2, height/2,0,5000);
 cam.setMinimumDistance(5);
 cam.setMaximumDistance(700);
 PanDragHandler = cam.getPanDragHandler();
 ZoomDragHandler = cam.getZoomDragHandler();
 cam.setLeftDragHandler(PanDragHandler);
 cam.setRightDragHandler(ZoomDragHandler);
// print(totalFreqCatp.sortKeys());
  stars = new ArrayList();
 for(int i=1; i<=1300;i++){
  stars.add(new star());
 }
model = new OBJModel(this, "testing.obj", POLYGON); 
model.scale(5);



 lights();
 //lipseMode(Corner);
 ellipseMode(CENTER);
 //***Writing the text****
 Cat=createFont("Cambria", 26,true);
 catStage   = createFont("Cambria",20, true);
 ttools = createFont("Cambria",18,true);
 tstage = createFont("Cambria",17,true);
 buttons = createFont("Cambria",18,true); 
 // cam = new PeasyCam(this,width/2, height/2, 0,5000);
 // cam.setMinimumDistance(5);
//  cam.setMaximumDistance(700);
 // PanDragHandler = cam.getPanDragHandler();
 // ZoomWheelHandler = cam.getZoomWheelHandler();
 // cam.setWheelHandler(ZoomWheelHandler);

 fill(81,72,175);
 //text("Hello", 10,100);
 //img = loadShape("3DAlien.obj");
 //phase1 = createFont("Arial", 8,true);
 //img = loadShape("SunAlien.obj");
//img.resize(200,200);

 }
//} 

public void draw () { 

  
  noStroke(); 
   smooth(); 
   background(0);
  // ZoomDragHandler.handleDrag(10,10);
  // PanDragHandler.handleDrag(10,10);
   //*****Write Texts and Create Legends************
    fill(281,10,10);
    textFont(Cat);
    fill(77, 130, 232);
    text("Cognitive Loads:"+cl+"%", 70,50);
    fill(0, 378, 238);
    text("Cognitive Processing:"+cp+"%", 110,590);
    fill(232 ,119, 77);
    text("Out of Reach Activities:"+OUR+"%", 930,50);
    fill(0, 255, 0);
    text("Hypothesis Testing:" +ht+"%", 930, 360);
    textFont(catStage);
    fill(243,253,309);
    text("Stage 1:   Stage 2:    Stage 3:    Stage 4:", 70,80);
    text("Stage 1:  Stage 2:  Stage 3: Stage 4: ", 110,620);
    text("Stage 1:  Stage 2:  Stage 3: Stage 4: ", 930,  80);
    text("Stage 1:  Stage 2:  Stage 3: Stage 4: ", 930, 390);
    textFont(ttools);
    fill(169, 136, 120);
    text("Alien Database:"+ad+"%",20,430);
    fill(139, 136, 12);
    text("SolarSystem Database:"+ss+"%",300,430);
    fill(139, 16, 120);
    text("Missions Database:"+md+"%",20, 480);
    fill(250, 139,  48);
    text("Concepts Database:"+ct+"%",300, 480);
    fill(39, 136, 120);
    text("Spectral Database:"+sd+"%",10,530);
    fill(18,  58, 137);
    text("Period table:"+pt+"%",300,530);
    fill(255, 136, 120);
    text("Probe Design:"+pd+"%",930,290);
    fill(239, 136, 20);
    text("Probe Launch:"+pl+"%",1150,290);
    fill(66 ,232,125);
    text("Mission Status:"+mc+"%",900,620);
    fill(109, 131, 20);
    text("Message Tool:"+mt+"%",1150,620);
    fill(175, 245, 220);
    text("Solution: ?",1000,670);
    textFont(tstage);
     fill(245,243,172);
    text("Stage 1:   Stage 2:    Stage 3:    Stage 4:", 05,450);
    text("Stage 1:  Stage 2:  Stage 3: Stage 4: ", 290,450);
    text("Stage 1:  Stage 2:  Stage 3: Stage 4: ",   5, 500);
    text("Stage 1:  Stage 2:  Stage 3: Stage 4: ", 290, 500);
     text("Stage 1:   Stage 2:    Stage 3:    Stage 4:", 20,550);
    text("Stage 1:  Stage 2:  Stage 3: Stage 4: ", 290,550);
    text("Stage 1:  Stage 2:  Stage 3: Stage 4: ", 880, 310);
    text("Stage 1:  Stage 2:  Stage 3: Stage 4: ",1130, 310);
     text("Stage 1:   Stage 2:    Stage 3:    Stage 4:", 930, 690);
     text("Stage 1:  Stage 2:  Stage 3: Stage 4: ", 850, 640);
     text("Stage 1:   Stage 2:    Stage 3:    Stage 4:",1100, 640);
    
    //Creates The Legend Button Commands******************
     fill(243,253,309);
    rect(370,0,20,20);
    textFont(buttons);
    text("Catergories",390,15);
    rect(500,00,20,20);
    text("Tools", 520,15);
     fill(255,0,0);
    rect(600,00,20,20);
    text("Stage 1", 620,15);
    fill(0, 0, 255);
    rect(700,00,20,20);
    text("Stage 2", 720,15);
    fill(237,255,3);
    rect(800,00,20,20);
    text("Stage 3", 820,15);
     fill(131,131,126);
    rect(900,00,20,20);
    text("Stage 4",920,15);
  
  
  
  
  
 //*****Draw Stars BackGrounds**************
  for (int i=0; i<= stars.size()-1;i++){
   star starUse= (star) stars.get(i);
    starUse.display();
  }
    
 pushMatrix(); 
 translate(width/2, height/2, 0); 
 rotateX(rotY); 
 rotateY(rotX); 
 scale(20.0f); 
 model.draw(); 
 popMatrix();
   
   //shape(img);
   //shape(img, (width/3)+95, (height/2)-95);
   //img.scale(0.25);
  
  



 
 //-----------Cognitive Process Planet+ Moons+ Orbits---------
 orbitDisplay(250, 660,100, 1);//Cognitive Process
 pushMatrix(); 

 //ranslate(600,600);
  popMatrix();
  pushMatrix();
planetDisplay (250,660,cp,0, 378, 238);//Cognitive Process Planet
  popMatrix(); 
  pushMatrix(); 


///-----Tools Supporting Out of Reach Activities -------------------
   orbitDisplay(1100, 180,200,1);//Probe Design Orbit
   orbitDisplay(1100, 180, 380, 1);//Probe Launch Orbit
  planetDisplay (1100, 180, OUR,232 ,119, 77);//OUR Sun
   
   pushMatrix();
   float a = (110/1.5f)* cos(thetaMars);
   float b = (110/3)* sin(thetaMars);
   planetDisplay(a,b, pd, 255, 136, 120);//Probe Design
   stageMoonDisplay(1,2,3,4);
   popMatrix();
   pushMatrix();
   float z =(180/1.5f)*cos(thetaJupiter);
   float u=(180/ 3) * sin(thetaJupiter);
  planetDisplay(z, u, pl, 239, 136, 20);//Probe Launch
  stageMoonDisplay(1,2,3,4);
  popMatrix();
   
   popMatrix();  
    pushMatrix();  

 //----Toools Supporting Hypothesis Testing---------------------------
  orbitDisplay(1100, 500, 200, 1);//saturn orbit 
  orbitDisplay(1100, 500, 350, 1);//saturn orbit 
  orbitDisplay(1100, 500, 500, 1);//saturn orbit 
  planetDisplay (1100, 500, ht, 0, 255, 0);//jupiter 
 //popMatrix();
 pushMatrix(); 
  
 float d = (110/1.5f) * cos(thetaMarsMoon1);
 float e = (110/3) * sin(thetaMarsMoon1);
 moonDisplay(d, e, mc, 66 ,232,125 ); //Mission Status
 stageMoonDisplay(1,2,3,4);
 //rotate(thetaMarsMoon2); 
 popMatrix();
 pushMatrix();
 float g = (170/1.5f) * cos(thetaMarsMoon2);
 float m = (170/3) * sin(thetaMarsMoon2);
 moonDisplay(g, m, mt, 109, 131, 20);//message tool
 stageMoonDisplay(1,2,3,4);
 popMatrix();
 pushMatrix();
 float v = (240/1.5f) * cos(thetaJupiter);
 float w = (240/3) * sin(thetaJupiter);
 moonDisplay(v, w, 1, 175, 245, 220);//solution tool
 stageMoonDisplay(1,2,3,4);
 popMatrix();
 popMatrix();
 pushMatrix();


  
  
 //-------------------------CognitiveLoads---------------------------------------------
  orbitDisplay(200,250,200, 1);//neptune orbit 
   orbitDisplay(200,250,350,1);
   orbitDisplay(200,250,500,1);
   orbitDisplay(200,250,650,1);
   orbitDisplay(200,250,800,1);
   orbitDisplay(200,250,950,1);
  planetDisplay (200, 250, cl,  77, 130, 232);//cognitive Load sun
//  //translate(0,-475); 
  pushMatrix();
  float h = (100 /1.5f)* cos(thetaMars);
  float i = (100 /3)* sin(thetaMars);
  planetDisplay(h, i, ct, 250, 139,  48); //concepts
  popMatrix();
  pushMatrix();
  float j = (180/1.5f)* cos(thetaMercury);
  float k = (180/3)* sin(thetaMercury);
moonDisplay(j, k, pt,  18,  58, 137);//periodic table
stageMoonDisplay(1,2,3,4);
  popMatrix();
  pushMatrix();
  float l = (250/1.5f)* cos(thetaVenus);
  float n = (250/3)* sin(thetaVenus );
  moonDisplay(l, n, sd,  39, 136, 120);//spectral database
  stageMoonDisplay(1,2,3,4);
  popMatrix();
  pushMatrix();
  float o =(330/1.5f)* cos(thetaEarth );
  float p =(330/3)* sin(thetaEarth );
  moonDisplay(o,p, md, 139, 16, 120);//missions database
  stageMoonDisplay(1,2,3,4);
  popMatrix();
  pushMatrix();
  float q = (400/1.5f)* cos(thetaSaturn);
  float r =(400/3)* sin(thetaSaturn);
  moonDisplay(q, r, ss, 139, 136, 12);//Solar System Database
  stageMoonDisplay(1,2,3,4);
  popMatrix();
  pushMatrix();
  float s =(470/1.5f)* cos(thetaPluto );
  float t =(470/3)* sin(thetaPluto );
  moonDisplay(s, t, ad, 169, 136, 120);//Alien Database
  stageMoonDisplay(1,2,3,4);
  popMatrix();

  popMatrix(); 
  pushMatrix(); 
  
  popMatrix(); 
  //INCREMENTS FOR PLANETS AND MOONS 
  thetaMercury +=0.015f; 
  thetaVenus +=0.008f; 
  thetaVenusMoon +=0.08f; 
  thetaEarth +=0.005f; 
  thetaEarthMoon +=0.05f; 
  thetaMars +=0.009f; 
  thetaMarsMoon1 +=0.03f; 
  thetaMarsMoon2 +=0.025f; 
  thetaJupiter += 0.04f; 
  thetaSaturn += 0.008f;
  thetaUranus += 0.002f; 
  thetaNeptune +=0.004f; 
  thetaPluto += 0.003f; 
//println("What is the value of thetaMercury?" +thetaMercury); 
    
 pushMatrix(); 
 translate(width/2, height/2, 0); 
 rotateX(rotY); 
 rotateY(rotX); 
 scale(20.0f); 
 model.draw(); 
 popMatrix();
   


//----------------MouseFunctions---------

} 

public void planetDisplay (float x, float y, float radius, float r, float g, float b){//planet display function 
//void planetDisplay(float x, float y, float radius, float r, float g, float b, float z){
noStroke(); 
//pointLight(r, g, b, 0, 255, 0); 
fill(r,g,b);
lights();
//ellipse(x,y, radius, radius);
translate(x,y);
sphere(radius);
}
public void moonDisplay (float x, float y, float radius, float r, float g, float b){//moon display 
noStroke(); 
fill(r, g, b); 
//ellipse(x, y, radius, radius); 
translate(x,y);
sphere(radius);
} 

public void orbitDisplay (float x, float y, float radius, float bold) { 
noFill(); 
stroke(255); 
strokeWeight(bold); 
ellipse (x, y, radius/1.5f, radius/3); 
} 
public void stageMoon1Display (float x, float y, float radius ){//moon display 
noStroke(); 
fill(0,255,0); 
//ellipse(x, y, radius, radius); 
translate(x,y);
sphere(radius);
} 
public void stageMoon2Display (float x, float y, float radius){//moon display 
noStroke(); 
fill(255,0,0); 
//ellipse(x, y, radius, radius); 
translate(x,y);
sphere(radius);
} 
public void stageMoon3Display (float x, float y, float radius){//moon display 
noStroke(); 
fill(0, 0, 255);
//ellipse(x, y, radius, radius); 
translate(x,y);
sphere(radius);
} 
public void stageMoon4Display (float x, float y, float radius){//moon display 
noStroke(); 
fill(237,255,3);
//ellipse(x, y, radius, radius); 
translate(x,y);
sphere(radius);
} 
public void stageMoonDisplay(float radius1, float radius2, float radius3, float radius4){
  pushMatrix();
   float co = (40 /1.5f)* cos(thetaMars);
   float fo = (40/3)* sin(thetaMars);
   //***Stages****
  pushMatrix();
   translate(-co,-fo);
   fill(255,0,0); 
   sphere(radius1);
   popMatrix();
   translate(co, fo);
   fill(0, 0, 255);
   sphere(radius2);
   popMatrix();
   pushMatrix();
   translate(co,-fo);
   fill(237,255,3);
   sphere(radius3);
   popMatrix();
   pushMatrix();
   translate(-co,fo,5);
   fill(131,131,126);
   sphere(radius4);
   popMatrix();
}
public void fileSelected(File selection) {
  
  if (selection == null) 
    println ("NO FILE SELECTED"); 
  else { 
    String[] lines = loadStrings (selection.getAbsolutePath()); 
    print(lines);
   
    //String[] lines = loadStrings("AlienRescueData.txt");

    ////--------------Creates the General Initial arrays-----------
    int[] arrStage = new int[lines.length]; //The phases array
    String[] arrTool = new String[lines.length]; //The tools array
    String[] arrCategory = new String[lines.length];
    float[] arrDuration = new float[lines.length];
    StringList freqTools= new StringList(lines.length);
    StringList freqCat = new StringList(lines.length);
    StringList freqTools1 = new StringList(lines.length);
    StringList freqTools2 = new StringList(lines.length);
    StringList freqTools3 = new StringList(lines.length);
    StringList freqTools4 = new StringList(lines.length);
    for (int i=1; i<lines.length; i++){
  
     String[] arrTokens= split(lines[i], '\t');
     int stage = PApplet.parseInt(arrTokens[0])+'\n';
     String tool = arrTokens[1];
     String category = arrTokens[2];
     float duration = PApplet.parseFloat(arrTokens[3]) +'\n';
     arrStage[i-1] = stage;
     arrTool[i-1] = tool;
     arrCategory[i-1] = category;
     arrDuration[i-1] = duration;
    }
    

  for (int i=1; i<lines.length; i++){
    freqTools.append(arrTool[i]);
    freqCat.append(arrCategory[i]);
    if(1 == PApplet.parseInt(arrStage[i])){
     freqTools1.append(arrTool[i]);
  }
   if(2 == PApplet.parseInt(arrStage[i])){
     freqTools2.append(arrTool[i]);
  }
   if(3 == PApplet.parseInt(arrStage[i])){
     freqTools3.append(arrTool[i]);
  }
  if(4 == PApplet.parseInt(arrStage[i])){
     freqTools4.append(arrTool[i]);
  }
  }
////---------Begins Extracting Unique Frequencies------------------
FloatDict totalFreqCat = new FloatDict();
FloatDict totalFreqTools = new FloatDict();
FloatDict stage1FreqCat = new FloatDict();
FloatDict stage1FreqTools = new FloatDict();
FloatDict stage2FreqCat= new FloatDict();
FloatDict stage2FreqTools = new FloatDict();
FloatDict stage3FreqCat = new FloatDict();
FloatDict stage3FreqTools = new FloatDict();
FloatDict stage4FreqCat= new FloatDict();
FloatDict stage4FreqTools= new FloatDict();


//**** Calculate Total Frequencies**********
IntDict totalFreqCatf= freqCat.getTally();
FloatDict totalFreqCatp = totalFreqCatf.getPercent();
OUR = totalFreqCatp.get("Activities") * 100;
ht = totalFreqCatp.get("Hypothesis Testing") *100;
cl = totalFreqCatp.get("Cognitive Load") * 100;
cp = totalFreqCatp.get("Cognitive Processing") * 100;
print(OUR);
IntDict totalFreqToolf= freqTools.getTally();
FloatDict totalFreqToolp = totalFreqToolf.getPercent();
ad = totalFreqToolp.get("alien database") *100;
ss = totalFreqToolp.get("solar system")*100;
md = totalFreqToolp.get("missions")* 100;
ct = totalFreqToolp.get("concepts")*100;
sd = totalFreqToolp.get("spectra")*100;
pt = totalFreqToolp.get("periodic table") *100;
pl = totalFreqToolp.get("probe launch") *100;
pd = totalFreqToolp.get("probe design") *100;
mt =( totalFreqToolp.get("message") + totalFreqToolp.get("message tool")) *100;
mc = totalFreqToolp.get("mission control") * 100;



//print(ht);


//IntDict totalFreqToolf= freqTools.getTally();
//FloatDict totalFreqToolp = totalFreqToolf.getPercent();
//ht = totalFreqCatp.get("Hypothesis Testing") *100;
//print(ht);









for(int i= 0; i< arrTool.length -1 ; i++){
  totalFreqCat.add(arrCategory[i],arrDuration[i]);
  totalFreqTools.add(arrTool[i],arrDuration[i]);
  if(1 == PApplet.parseInt(arrStage[i])){
    stage1FreqCat.add(arrCategory[i],arrDuration[i]);
    stage1FreqTools.add(arrTool[i],arrDuration[i]);
  }
  if(2 == PApplet.parseInt(arrStage[i])){
    stage2FreqCat.add(arrCategory[i],arrDuration[i]);
    stage2FreqTools.add(arrTool[i],arrDuration[i]);
  }
  if(3 == PApplet.parseInt(arrStage[i])){
    stage3FreqCat.add(arrCategory[i],arrDuration[i]);
    stage3FreqTools.add(arrTool[i],arrDuration[i]);
  }
  if(4 == PApplet.parseInt(arrStage[i])){
    stage4FreqCat.add(arrCategory[i],arrDuration[i]);
    stage4FreqTools.add(arrTool[i],arrDuration[i]);
  }
}
FloatDict totalCat = totalFreqCat.getPercent();
FloatDict totalTool = totalFreqTools.getPercent();
FloatDict Stage1cat = stage1FreqCat.getPercent();
FloatDict stage1tools = stage1FreqTools.getPercent();
FloatDict Stage2cat = stage2FreqCat.getPercent();
FloatDict stage2tools = stage2FreqTools.getPercent();
FloatDict Stage3cat = stage3FreqCat.getPercent();
FloatDict stage3tools = stage3FreqTools.getPercent();
FloatDict Stage4cat = stage4FreqCat.getPercent();
FloatDict stage4tools = stage4FreqTools.getPercent();

 } 
}










class star { 


  int xPos, yPos, starSize; 


  float flickerRate, light; 


  boolean rise; 


  star(){ 


    flickerRate = random(2,5);  


    starSize = PApplet.parseInt(random(2,5)); 


    xPos = PApplet.parseInt(random(0,1500 - starSize)); 


    yPos = PApplet.parseInt(random(0,700 - starSize)); 


    light = random(10,245); 


    rise = true; 


  } 


  public void display(){ 


    if(light >= 245){ 


      rise = false; 


    } 


    if(light <= 10){ 


      flickerRate = random(2,5); 


      starSize = PApplet.parseInt(random(2,5)); 


      rise = true; 


      xPos = PApplet.parseInt(random(0,1500 - starSize)); 


      yPos = PApplet.parseInt(random(0,700 - starSize)); 


    } 


    if(rise == true){ 


      light += flickerRate; 


    } 


    if(rise == false){ 


      light -= flickerRate; 


    } 


    fill(light); 


    rect(xPos, yPos,starSize,starSize); 


  } 


} 
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--full-screen", "--bgcolor=#666666", "--stop-color=#cccccc", "WriteLegendText" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
