#ifndef_hw4_funcs_
#define_hw4_funcs_

particle  updatePosition(vector *** velocity, particle par)

#endif